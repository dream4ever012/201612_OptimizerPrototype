# -*- coding: utf-8 -*-
"""
Created on Wed Dec 14 11:28:09 2016

@author: HKIM85
"""
#cd 'C:\Users\hkim85\Desktop\Caleb\OneDrive\Documents\Caleb\2016_PhDinCS\201603_IndStudy\201612_OptimizerPrototype'

import ResourceString as rs
#import utilities as utl
import predicate as pds



class Table(object):    
    def __init__(self, table_name='DFT', card=0, cum_cost=0, 
                 preds=pds.Predicates()):
        self.table_name = table_name
        self.card = card
        self.cum_cost = cum_cost
        # to check 
        self.TMbool = False
        # to contain normal predicates
        self.norm_preds = [pred for pred in preds.preds if pred.norm_sel_bool == True]
        # to contain UDF predicates
        self.UDF_preds = [pred for pred in preds.preds if pred.norm_sel_bool == False]
        if (len(self.UDF_preds)==0): self.is_UDF = False
        else: self.is_UDF = True
    
    # cannot change Table name after instantiation
    def __str__(self):
        return self.table_name#'{}'.format(self.table_name)
    
    def __repr__(self):
        return '{}'.format(self.table_name) # self.table_name
        
    def getTableName(self):
        return self.table_name
        # return self.table_name
    
    # cannot change cardinality
    def getCard(self):
        return self.card
        
    def getCum_cost(self):
        return self.cum_cost
    
    def addCum_cost(self, tmp_cost):
        self.cum_cost += tmp_cost
    
    """ functions for Predicates """
    """ TO-DO: test this functions """
    def add(self, pred, is_norm_pred=True):
        if (is_norm_pred==True):
            self.norm_preds.add(pred)
        elif (is_norm_pred==False):
            self.UDF_preds.add(pred)
        
    def remove(self, pred, is_norm_pred=True):
        if (is_norm_pred == True):
            self.norm_preds.remove(pred)
        elif (is_norm_pred == False):
            self.UDF_preds.remove(pred)
    
    def has_normPred(self):
        if (len(self.norm_preds)>0): True
        else: False
    
    def has_mult_normPred(self):
        if (len(self.norm_preds)>1): True
        else: False
    
    def has_UDFPred(self):
        if (len(self.UDF_preds)>0): True
        else: False
""" TO-DO: How to delete """
    def processNorm_preds(self):
        
        #if ()
        None
    

class TM(Table):   
    def __init__(self, table_name='DFT', card=0, cum_cost=0, related_tbls= []):        
        self.table_name = table_name
        self.card = card
        self.cum_cost = cum_cost
        self.related_tbls = related_tbls # later check with 'is None' to see if TM is connected with Normal Table
        self.TMbool = True
                
    # cannot change Table name after instantiation
    def __str__(self):
        return self.table_name#'{}'.format(self.table_name)
    
    def __repr__(self):
        return '{}'.format(self.table_name) # self.table_name
        
    def getTableName(self):
        return self.table_name
        # return self.table_name
    
    # cannot change cardinality
    def getCard(self):
        return self.card
        
    def getCum_cost(self):
        return self.cum_cost
    
    def addCum_cost(self, tmp_cost):
        self.cum_cost += tmp_cost    
    



def test_prep():
    pred0 = pds.Predicate(pred_name = 'pred0', norm_sel_bool = True)          
    pred1 = pds.Predicate(pred_name = 'pred1', norm_sel_bool = True)
    pred2 = pds.Predicate(pred_name = 'pred2', norm_sel_bool = True)
    # 
    preds0 = pds.Predicates()
    preds0.add(pred0)
    preds0.add(pred1)
    preds0.add(pred2)
    return preds0

preds0 = test_prep()
###############################
# test1) create a table with normal predicates
#### ===>> SUCCESS
# 
###############################
def test1():
    A = Table('A', card=80000, cum_cost=0, preds=preds0)
    print vars(A)
    
test1()

B = Table('B', card=60000, cum_cost=0, preds=pds.Predicates())
C = Table('C', card=100000, cum_cost=0,preds=pds.Predicates())

