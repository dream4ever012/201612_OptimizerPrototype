# -*- coding: utf-8 -*-
"""
Created on Thu Jan 19 13:15:41 2017

@author: HKIM85
"""

from query1_1 as qry

