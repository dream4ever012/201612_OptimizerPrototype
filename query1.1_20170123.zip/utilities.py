# -*- coding: utf-8 -*-
"""
Created on Wed Dec 14 11:48:10 2016

@author: HKIM85
"""

import Table1_1 as tbl

class Utilities(object):
    def cardCnt(self, path):
        None
        
    def joinCost(self, table1, table2):
        table1.getCard
        None